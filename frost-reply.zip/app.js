/*
 * FROST — a fully static, browser-only reply helper.
 * Text recognition uses Tesseract.js on the user's device.
 * Response selection is transparent rule-based logic, not an LLM.
 */
(() => {
  'use strict';

  const $ = (id) => document.getElementById(id);
  const ui = {
    dropzone: $('dropzone'), screenshotInput: $('screenshot-input'),
    emptyDrop: $('dropzone-empty'), previewBox: $('image-preview-box'),
    preview: $('image-preview'), fileActions: $('file-actions'),
    fileName: $('file-name'), removeImage: $('remove-image'),
    textarea: $('message-input'), characterCount: $('character-count'),
    generate: $('generate-btn'), buttonCaption: $('button-caption'),
    progress: $('ocr-progress'), emptyState: $('empty-state'),
    resultState: $('result-state'), detectedTitle: $('detected-title'),
    analysisDescription: $('analysis-description'),
    safetyNotice: $('safety-notice'), safetyText: $('safety-text'),
    recognizedDetails: $('recognized-details'), recognizedText: $('recognized-text'),
    editRecognized: $('edit-recognized'), responseList: $('response-list'),
    toast: $('toast')
  };

  const state = {
    file: null,
    previewUrl: null,
    tone: 'cool',
    busy: false,
    ocrText: '',
    worker: null,
    toastTimer: null,
    ocrScriptPromise: null
  };

  const examples = {
    insult: 'אתה כזה מטומטם, אין טעם בכלל לדבר איתך.',
    pressure: 'למה אתה לא עונה לי עכשיו? אתה חייב לענות, נו כבר!',
    threat: 'אם לא תעשה מה שאני אומר, אני אפרסם את התמונות שלך.'
  };

  const patterns = {
    threat: [
      /סחיטה|סוחט|אפרסם|אחשוף|אפיץ|יפרסם|יפיץ|להפיץ|אדליף|אשלח לכולם|כולם יראו|אספר לכולם|איומים|מאיים|תמונות שלך/iu,
      /blackmail|extort|expos(e|ing) you|leak (your|those)|post (your|those) (photos|pics|pictures)|share your (photos|pics|pictures)|send your (photos|pics|pictures)|tell everyone|threaten/iu,
      /(?:אם לא|אלא אם|unless|if you don.t).{0,100}(?:אפרסם|אחשוף|אפיץ|תמונות|כסף|לכולם|expose|leak|post|photos|pictures|pics)/iu
    ],
    insult: [
      /מטומטם|טיפש|סתום|אפס|דפוק|מפגר|מכוער|אידיוט|לוזר|עלוב|סתמי|שתוק|אידיוטית|סתומה/iu,
      /stupid|idiot|loser|moron|dumb|shut up|pathetic|ugly|worthless/iu
    ],
    guilt: [
      /אם באמת היה אכפת|אם היית חבר|חבר אמיתי|אחרי כל מה|אתה מאכזב|את מאכזבת|לא אכפת לך|בגללך|תתבייש|תתביישי/iu,
      /if you (really )?cared|a real friend would|after everything i.ve done|you don.t care|your fault|disappointed in you/iu
    ],
    pressure: [
      /תענה כבר|תעני כבר|תענה עכשיו|תעני עכשיו|תשיב עכשיו|חייב לענות|חייבת לענות|נו כבר|למה אתה מסנן|למה את מסננת|מיד עכשיו|אין לך ברירה|מהר תענה|תענה לי/iu,
      /answer me|reply now|respond now|right now|you have to reply|stop ignoring|why are you ignoring|no choice|do it now/iu
    ]
  };

  const messages = {
    he: {
      threat: {
        title: 'איום או ניסיון סחיטה',
        description: 'יש כאן סימנים לאיום או לחץ חמור. לא כדאי להיגרר לוויכוח; שמירה על ראיות וקבלת עזרה חשובות יותר מתגובה שנונה.',
        safety: 'לא חייבים לענות בכלל. אל תשלח כסף, תמונות או פרטים נוספים. שמור צילום מסך ופנה להורה, למבוגר שאתה סומך עליו או לגורם מתאים. אם יש סכנה מיידית, פנה לשירותי החירום.',
        cool: [
          'אני לא ממשיך שיחה שיש בה איומים.',
          'קיבלתי את ההודעה. אני שומר תיעוד ולא ממשיך את השיחה.',
          'אני מסיים את השיחה הזו.'
        ],
        firm: [
          'איומים אינם דרך לדבר איתי. אני לא נענה לדרישות כאלה.',
          'אני שומר את ההתכתבות ופונה לעזרה. לא אמשיך לדון בזה.',
          'אין לי מה להוסיף. השיחה הסתיימה.'
        ],
        end: [
          'אני מסיים את השיחה. אל תפנה אליי באיומים.',
          'לא אמשיך להתכתב בנושא הזה.',
          'השיחה נגמרה מבחינתי.'
        ]
      },
      insult: {
        title: 'עלבונות או זלזול',
        description: 'נראה שיש כאן אמירה פוגענית. אפשר לענות באופן מדויק בלי להחזיר עלבון.',
        cool: [
          'אם יש לך משהו להגיד, אפשר לומר אותו בלי להעליב.',
          'אני מעדיף שיחה מכבדת. יש לך משהו ענייני לומר?',
          'לא ממשיך שיחה שבה מדברים אליי ככה.'
        ],
        firm: [
          'לדבר אליי ככה לא יקדם את השיחה.',
          'אפשר לחלוק עליי, אבל לא להעליב אותי.',
          'כשיהיה אפשר לדבר בכבוד, נמשיך.'
        ],
        end: [
          'אני לא מתכוון להתווכח עם עלבונות. נעצור כאן.',
          'אין טעם להמשיך את השיחה בסגנון הזה.',
          'מבחינתי השיחה הסתיימה.'
        ]
      },
      guilt: {
        title: 'ניסיון לעורר אשמה',
        description: 'הניסוח עשוי לגרום לך להרגיש מחויב לפעול מתוך אשמה. מותר לך לבחור מה מתאים לך.',
        cool: [
          'אני מבין שזה חשוב לך, אבל אני צריך להחליט בעצמי.',
          'אפשר לדבר על מה שמפריע לך בלי לגרום לי להרגיש אשם.',
          'אני לא מקבל החלטות מתוך לחץ או אשמה.'
        ],
        firm: [
          'זה שמשהו חשוב לך לא אומר שאני חייב להסכים.',
          'בוא נדבר על העניין עצמו, בלי להפעיל רגשות אשמה.',
          'הגבול שלי נשאר גם אם זה לא נעים לשמוע.'
        ],
        end: [
          'אני לא רוצה להמשיך שיחה שמבוססת על רגשות אשמה.',
          'אמרתי מה אני חושב, ואני עוצר כאן.',
          'נחזור לזה רק אם אפשר לדבר בכבוד.'
        ]
      },
      pressure: {
        title: 'לחץ לקבל תגובה',
        description: 'הצד השני כנראה דורש מענה מיידי. מותר לך לקחת זמן ולא לענות תחת לחץ.',
        cool: [
          'אני אענה כשיהיה לי זמן. אין צורך ללחוץ.',
          'ראיתי את ההודעה, ואחזור אליך כשאוכל.',
          'אני מעדיף שנדבר בלי לחץ.'
        ],
        firm: [
          'לחץ לא יגרום לי לענות מהר יותר.',
          'אני קובע מתי אני פנוי לענות.',
          'אם השיחה תמשיך בלחץ, אעצור אותה.'
        ],
        end: [
          'אני לא פנוי לשיחה עכשיו. נדבר בהמשך.',
          'אני מפסיק להתכתב כרגע.',
          'אענה בזמן שמתאים לי, לא מתוך דרישה.'
        ]
      },
      general: {
        title: 'שיחה מתוחה או לא ברורה',
        description: 'לא זוהה סוג מסוים של פגיעה. הנה תשובות כלליות שיכולות לעזור להחזיר את השיחה למסלול.',
        cool: [
          'קראתי מה שכתבת. אשמח לדבר על זה בצורה רגועה.',
          'אני מבין את מה שאתה אומר. בוא נדבר עניינית.',
          'כרגע אני מעדיף לא להתווכח.'
        ],
        firm: [
          'בוא נתמקד במה שחשוב, בלי להפוך את זה לריב.',
          'אני מוכן לדבר, כל עוד השיחה נשארת מכבדת.',
          'אני שומע אותך, אבל לא מסכים עם הדרך שבה זה נאמר.'
        ],
        end: [
          'אני מעדיף לעצור כאן ולחזור לזה מאוחר יותר.',
          'אני מסיים את השיחה לעכשיו.',
          'אין לי עוד מה להוסיף כרגע.'
        ]
      }
    },
    en: {
      threat: {
        title: 'Threat or blackmail',
        description: 'This message may contain threats or coercion. Your safety matters more than having a clever comeback.',
        safety: 'You do not have to reply. Do not send money, photos, or more personal information. Save evidence and tell a trusted adult or appropriate authority. If you are in immediate danger, contact emergency services.',
        cool: [
          'I won’t continue a conversation that involves threats.',
          'I have received your message. I’m keeping a record and won’t engage further.',
          'I am ending this conversation.'
        ],
        firm: [
          'Threats are not an acceptable way to speak to me. I won’t comply.',
          'I am keeping this conversation and seeking support. I won’t discuss it further.',
          'There is nothing more to discuss.'
        ],
        end: [
          'This conversation is over. Do not threaten me again.',
          'I won’t engage any further on this.',
          'I am ending the conversation now.'
        ]
      },
      insult: {
        title: 'Insults or disrespect',
        description: 'This sounds disrespectful. You can set a boundary without insulting the other person.',
        cool: [
          'You can make your point without insulting me.',
          'I’m open to a respectful conversation if you are.',
          'I’m not continuing a conversation in that tone.'
        ],
        firm: [
          'Speaking to me like that won’t help your point.',
          'You can disagree without being disrespectful.',
          'We can talk when you’re ready to be respectful.'
        ],
        end: [
          'I’m not arguing over insults. Let’s stop here.',
          'There’s no reason to continue in this tone.',
          'I’m ending this conversation.'
        ]
      },
      guilt: {
        title: 'Possible guilt pressure',
        description: 'This might be trying to make you feel guilty for having a boundary.',
        cool: [
          'I hear you, but I still need to make my own decision.',
          'We can talk about this without using guilt.',
          'I don’t want to decide something under pressure.'
        ],
        firm: [
          'Something mattering to you doesn’t mean I have to agree.',
          'Let’s discuss the issue, not try to make each other feel guilty.',
          'My boundary still stands.'
        ],
        end: [
          'I won’t continue a conversation built around guilt.',
          'I’ve said what I need to say.',
          'We can revisit this when it’s respectful.'
        ]
      },
      pressure: {
        title: 'Pressure to respond',
        description: 'They seem to be demanding an immediate response. You can take your time.',
        cool: [
          'I’ll reply when I have time. There’s no need to push.',
          'I saw your message. I’ll get back to you when I can.',
          'I’d rather we talk without pressure.'
        ],
        firm: [
          'Pressuring me won’t make me respond faster.',
          'I decide when I’m available to reply.',
          'If the pressure continues, I’ll stop responding.'
        ],
        end: [
          'I’m not available to talk right now.',
          'I’m stepping away from this conversation.',
          'I’ll answer in my own time.'
        ]
      },
      general: {
        title: 'Unclear or tense conversation',
        description: 'No specific harmful pattern stood out. Here are calm, general replies.',
        cool: [
          'I read your message. I’m happy to talk calmly.',
          'I hear what you’re saying. Let’s keep this constructive.',
          'I’d rather not argue right now.'
        ],
        firm: [
          'Let’s focus on the issue instead of turning this into an argument.',
          'I’m willing to talk as long as we keep it respectful.',
          'I hear you, but I don’t agree with the way that was said.'
        ],
        end: [
          'I’d rather stop here and come back to this later.',
          'I’m ending this conversation for now.',
          'I don’t have anything else to add right now.'
        ]
      }
    }
  };

  function detectLanguage(text) {
    const heb = (text.match(/[\u0590-\u05FF]/g) || []).length;
    const lat = (text.match(/[a-z]/gi) || []).length;
    return heb >= lat * 0.55 ? 'he' : 'en';
  }

  function classify(text) {
    const normalized = String(text).replace(/[\u200E\u200F\u202A-\u202E]/g, ' ').slice(0, 6000);
    const type = ['threat', 'insult', 'guilt', 'pressure'].find((candidate) =>
      patterns[candidate].some((pattern) => pattern.test(normalized))
    );
    return { category: type || 'general', language: detectLanguage(normalized) };
  }

  function showToast(message) {
    window.clearTimeout(state.toastTimer);
    ui.toast.textContent = message;
    ui.toast.classList.add('show');
    state.toastTimer = window.setTimeout(() => ui.toast.classList.remove('show'), 2600);
  }

  function updateCount() {
    ui.characterCount.textContent = `${ui.textarea.value.length} / 6000`;
  }

  function setProgress(message) {
    ui.progress.hidden = !message;
    ui.progress.textContent = message || '';
  }

  function setBusy(busy) {
    state.busy = busy;
    ui.generate.disabled = busy;
    ui.buttonCaption.textContent = busy ? 'מזהה את ההודעה…' : 'צור לי תשובה';
  }

  function releasePreview() {
    if (state.previewUrl) URL.revokeObjectURL(state.previewUrl);
    state.previewUrl = null;
  }

  function removeImage() {
    releasePreview();
    state.file = null;
    state.ocrText = '';
    ui.screenshotInput.value = '';
    ui.preview.removeAttribute('src');
    ui.previewBox.hidden = true;
    ui.emptyDrop.hidden = false;
    ui.fileActions.hidden = true;
    ui.recognizedDetails.hidden = true;
  }

  function acceptFile(file) {
    if (!file || !file.type.startsWith('image/')) {
      showToast('אפשר להעלות קובץ תמונה בלבד');
      return;
    }
    if (file.size > 12 * 1024 * 1024) {
      showToast('בחר תמונה שגודלה עד 12MB');
      return;
    }
    removeImage();
    state.file = file;
    state.previewUrl = URL.createObjectURL(file);
    ui.preview.src = state.previewUrl;
    ui.previewBox.hidden = false;
    ui.emptyDrop.hidden = true;
    ui.fileName.textContent = file.name || 'תמונה מהלוח';
    ui.fileActions.hidden = false;
    ui.textarea.value = '';
    updateCount();
    setProgress('התמונה מוכנה. לחץ על „צור לי תשובה” כדי לזהות את הטקסט.');
  }

  async function loadOcrScript() {
    if (window.Tesseract?.createWorker) return;
    if (state.ocrScriptPromise) return state.ocrScriptPromise;
    state.ocrScriptPromise = new Promise((resolve, reject) => {
      const script = document.createElement('script');
      script.src = 'https://cdn.jsdelivr.net/npm/tesseract.js@6.0.1/dist/tesseract.min.js';
      script.async = true;
      script.onload = () => window.Tesseract?.createWorker ? resolve() : reject(new Error('OCR unavailable'));
      script.onerror = () => reject(new Error('OCR CDN unavailable'));
      document.head.appendChild(script);
    }).catch((error) => {
      state.ocrScriptPromise = null;
      throw error;
    });
    return state.ocrScriptPromise;
  }

  async function recognizeText(file) {
    setProgress('מכין זיהוי טקסט מקומי. בפעם הראשונה צריך להוריד רכיבי OCR…');
    await loadOcrScript();
    if (!state.worker) {
      state.worker = await window.Tesseract.createWorker('heb+eng', 1, {
        logger(info) {
          if (info.status === 'recognizing text') {
            setProgress(`מזהה את הטקסט שבתמונה… ${Math.round((info.progress || 0) * 100)}%`);
          }
        }
      });
    }
    const result = await state.worker.recognize(file);
    return (result?.data?.text || '').trim();
  }

  async function copyText(content, button) {
    try {
      if (navigator.clipboard?.writeText) {
        await navigator.clipboard.writeText(content);
      } else {
        // For local file previews and older browser contexts.
        const temp = document.createElement('textarea');
        temp.value = content;
        temp.style.position = 'fixed';
        temp.style.opacity = '0';
        temp.setAttribute('readonly', '');
        document.body.appendChild(temp);
        temp.select();
        const success = document.execCommand('copy');
        temp.remove();
        if (!success) throw new Error('copy failed');
      }
      const original = button.textContent;
      button.textContent = '✓ הועתק';
      button.classList.add('copied');
      showToast('התשובה הועתקה ללוח');
      window.setTimeout(() => {
        button.textContent = original;
        button.classList.remove('copied');
      }, 2100);
    } catch (_) {
      showToast('לא ניתן להעתיק אוטומטית. אפשר לסמן ולהעתיק את הטקסט.');
    }
  }

  function render(text, fromOcr) {
    const { category, language } = classify(text);
    const result = messages[language][category];
    ui.detectedTitle.textContent = result.title;
    ui.analysisDescription.textContent = result.description;
    ui.safetyNotice.hidden = category !== 'threat';
    if (category === 'threat') ui.safetyText.textContent = result.safety;

    const shouldShowOcr = fromOcr || Boolean(state.ocrText && text === state.ocrText);
    ui.recognizedDetails.hidden = !shouldShowOcr;
    if (shouldShowOcr) ui.recognizedText.textContent = text;

    ui.responseList.replaceChildren();
    const cards = result[state.tone];
    const labels = language === 'he'
      ? ['✦ ההצעה שלנו', 'אפשרות נוספת', 'להציב גבול']
      : ['✦ Our pick', 'Another option', 'Set a boundary'];

    cards.forEach((response, index) => {
      const card = document.createElement('article');
      card.className = `response-card${index === 0 ? ' recommended' : ''}`;
      const head = document.createElement('div');
      head.className = 'response-card-head';
      const title = document.createElement('span');
      title.textContent = labels[index];
      const copy = document.createElement('button');
      copy.type = 'button';
      copy.className = 'copy-button';
      copy.setAttribute('aria-label', `העתק תשובה ${index + 1}`);
      copy.textContent = '▢ העתק';
      copy.addEventListener('click', () => copyText(response, copy));
      const paragraph = document.createElement('p');
      paragraph.className = 'response-text';
      paragraph.dir = language === 'he' ? 'rtl' : 'ltr';
      paragraph.textContent = response;
      head.append(title, copy);
      card.append(head, paragraph);
      ui.responseList.appendChild(card);
    });

    ui.emptyState.hidden = true;
    ui.resultState.hidden = false;
    if (window.innerWidth < 791) {
      ui.resultState.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    }
  }

  async function generate() {
    if (state.busy) return;
    let text = ui.textarea.value.trim();
    let fromOcr = false;
    if (!text && !state.file) {
      showToast('צריך קודם להעלות תמונה או להדביק הודעה');
      ui.textarea.focus();
      return;
    }
    if (!text && state.file) {
      setBusy(true);
      try {
        text = await recognizeText(state.file);
        if (text.replace(/\s/g, '').length < 5) {
          setProgress('לא הצלחנו לקרוא מספיק טקסט. נסה צילום חד יותר או הדבק את ההודעה ידנית.');
          showToast('לא זוהה מספיק טקסט בתמונה');
          return;
        }
        ui.textarea.value = text.slice(0, 6000);
        state.ocrText = ui.textarea.value;
        updateCount();
        text = ui.textarea.value;
        fromOcr = true;
      } catch (error) {
        console.warn('OCR failed:', error);
        setProgress('זיהוי התמונה לא זמין כרגע. בדוק חיבור לאינטרנט והדבק את ההודעה כטקסט.');
        showToast('לא הצלחנו לזהות טקסט. אפשר לנסות שוב או להדביק ידנית.');
        return;
      } finally {
        setBusy(false);
      }
    }
    setProgress('');
    render(text, fromOcr);
  }

  ui.screenshotInput.addEventListener('change', (event) => {
    acceptFile(event.target.files?.[0]);
  });
  ui.dropzone.addEventListener('click', () => ui.screenshotInput.click());
  ui.dropzone.addEventListener('keydown', (event) => {
    if (event.key === 'Enter' || event.key === ' ') {
      event.preventDefault();
      ui.screenshotInput.click();
    }
  });
  ['dragenter', 'dragover'].forEach((type) => ui.dropzone.addEventListener(type, (event) => {
    event.preventDefault();
    ui.dropzone.classList.add('is-dragover');
  }));
  ['dragleave', 'drop'].forEach((type) => ui.dropzone.addEventListener(type, (event) => {
    event.preventDefault();
    ui.dropzone.classList.remove('is-dragover');
    if (type === 'drop' && event.dataTransfer?.files?.[0]) acceptFile(event.dataTransfer.files[0]);
  }));
  document.addEventListener('paste', (event) => {
    const item = Array.from(event.clipboardData?.items || []).find((value) => value.type.startsWith('image/'));
    if (item) {
      event.preventDefault();
      acceptFile(item.getAsFile());
      showToast('התמונה הודבקה בהצלחה');
    }
  });
  ui.removeImage.addEventListener('click', removeImage);
  ui.textarea.addEventListener('input', updateCount);
  ui.generate.addEventListener('click', generate);
  ui.editRecognized.addEventListener('click', () => {
    ui.textarea.focus();
    ui.textarea.scrollIntoView({ behavior: 'smooth', block: 'center' });
    showToast('ערוך את הטקסט ולחץ שוב על יצירת תשובה');
  });
  document.querySelectorAll('[data-example]').forEach((button) => button.addEventListener('click', () => {
    ui.textarea.value = examples[button.dataset.example];
    updateCount();
    setProgress('');
    ui.textarea.focus();
  }));
  document.querySelectorAll('[data-tone]').forEach((button) => button.addEventListener('click', () => {
    state.tone = button.dataset.tone;
    document.querySelectorAll('[data-tone]').forEach((option) => {
      const selected = option === button;
      option.classList.toggle('is-selected', selected);
      option.setAttribute('aria-pressed', String(selected));
    });
    // If there is already a result, update the suggestions immediately.
    if (!ui.resultState.hidden && ui.textarea.value.trim()) render(ui.textarea.value.trim(), false);
  }));
  window.addEventListener('pagehide', () => {
    releasePreview();
    if (state.worker) state.worker.terminate().catch(() => {});
  });
})();
